// created in March 2021 for use with the new Reservoir() "class"

function formCalcVols () {
   var volArr = []
   var lostVol = 3000 // 3 ml added for filling the inv pyramids
   var volIncBeadsPlate = 1.15 // 15% more volume will be added to the volumes in the beads plate
   var volIncReagPlate = 1.00 // same --> set it to 1.10 for normal run!

   formInfo = ""
   reagVolSolv1 = "Empty"
   reagVolSolv2 = "Empty"
   reagVolSolv3 = "Empty"
   reagVolAcN = "Empty"
   reagVolABC = "Empty"
   reagVolTFA = "Empty"
   reagVolBeads = "Empty"
   reagVolTrypsin = "Empty"
   reagVolReduction = "Empty"
   reagVolAlkylation = "Empty"

   // modify volumes according to the check boxes
   var _volReduction = (doReduction) ? volReduction : 0
   var _volAlkylation = (doAlkylation) ? volAlkylation : 0
   var _volBeads = (doBeadsAcN) ? volBeads : 0
   var _volBeadsAcN = (doBeadsAcN) ? volBeadsAcN : 0
   var _volSolv1 = (doEtOH && !!cyclesSolv1) ? volSolv1 : 0
   var _volSolv2 = (doEtOH && !!cyclesSolv2) ? volSolv2 : 0
   var _volSolv3 = (doEtOH && !!cyclesSolv3) ? volSolv3 : 0
   var _volAcN = (doAcN) ? volAcN : 0
   var _volABC = (doABCTrypsin) ? volABC : 0
   var _volTrypsin = (doABCTrypsin) ? volTrypsin : 0
   var _volTFA = (doAcidificationRecovery) ? volTFA : 0

   // check addition to sample plate
   if (_volSolv1 > sampleMaxVol) {
      formInfo = "Wash Solv 1 will exceed sample plate capacity" 
      return false
   }
   else if (_volSolv2 > sampleMaxVol) {
      formInfo = "Wash Solv 2 will exceed sample plate capacity" 
      return false
   }
   else if (_volSolv3 > sampleMaxVol) {
      formInfo = "Wash Solv 3 will exceed sample plate capacity" 
      return false
   }
   else if (_volAcN > sampleMaxVol) {
      formInfo = "Wash AcN will exceed sample plate capacity"
      return false
   }    
   else if ((_volABC+_volTrypsin) > sampleMaxVol) {
      formInfo = "Volume of ABC + Trypsin will exceed sample plate capacity"
      return false
   }    
   else if (_volTFA > sampleMaxVol) {
      formInfo = "Volume of TFA will exceed sample plate capacity"
      return false
   }       
	// increase all volumes in the reagent plate by 10%
	_volSolv1 *= volIncReagPlate
	_volSolv2 *= volIncReagPlate
	_volSolv3 *= volIncReagPlate
	_volAcN *= volIncReagPlate
	_volABC *= volIncReagPlate
	_volTFA *= volIncReagPlate
	_volBeadsAcN *= volIncReagPlate
	
// calculate volumes for Solv1, Solv2 and Solv3
   var _vols = [_volSolv1,_volSolv2,_volSolv3] // can't use "this" with local variables
   for (i=1; i<4; i++) {
	   volPerReservoirCol = _vols[i-1] * this["cyclesSolv"+i] * 8 * nCols + lostVol
	   if ( volPerReservoirCol > reagentsMaxVol*8) {
		   formInfo = "Wash Solv " + i +" will exceed reagents plate capacity"
		   this["reagVolSolv"+i] = "*Error"
		   return false
	   }
	   else {
		    this["reagVolSolv"+i] = (volPerReservoirCol > lostVol) ? volPerReservoirCol : "Empty"
	   }
	}
 

 tmp =  _volBeadsAcN*8*nCols + _volAcN * cyclesAcN * nCols * 8 + lostVol
   if (tmp > reagentsMaxVol*8) {
      formInfo = "Total AcN will exceed reagents plate capacity"
      reagVolAcN = "*Error"
      return false
   }
   else {
      reagVolAcN = (tmp <= lostVol) ? "Empty" : tmp
   }

   
   tmp = _volABC * nCols * 8 + lostVol
    if (tmp > reagentsMaxVol*8) {
      formInfo = "Total ABC will exceed reagents plate capacity"
      reagVolABC = "*Error"
      return false
   }
   else {
      reagVolABC = (tmp <= lostVol) ? "Empty" : tmp
   }

    tmp = _volTFA * nCols * 8 + lostVol
    if (tmp > reagentsMaxVol*8) {
      formInfo = "Total TFA will exceed reagents plate capacity"
      reagVolTFA = "*Error"
      return false
   }
   else {
      reagVolTFA = (tmp <= lostVol) ? "Empty" : tmp
   }

   // check beads plate
   // incrementing the volumes in the beads plate well by 15%
   tmp  = _volBeads * nCols
   if (tmp > beadsMaxVol) {
      formInfo = "Beads volume will exceed beads plate capacity"
      reagVolBeads = "*Error"
      return false
   }
   else {
      reagVolBeads = (!tmp) ? "Empty" : tmp * volIncBeadsPlate
   }

  tmp  = _volTrypsin * nCols
   if (tmp > beadsMaxVol) {
      formInfo = "Trypsin volume will exceed beads plate capacity"
      reagVolTrypsin = "*Error"
      return false
   }
   else {
      reagVolTrypsin = (!tmp) ? "Empty" : tmp * volIncBeadsPlate
   }

  tmp  = _volReduction * nCols
   if (tmp > beadsMaxVol) {
      formInfo = "Reductant volume will exceed beads plate capacity"
      reagVolReduction = "*Error"
      return false
   }
   else {
      reagVolReduction = (!tmp) ? "Empty" : tmp * volIncBeadsPlate
   }

  tmp  = _volAlkylation * nCols
   if (tmp > beadsMaxVol) {
      formInfo = "Alkylant volume will exceed beads plate capacity"
      reagVolAlkylation = "*Error"
      return false
   }
   else {
      reagVolAlkylation = (!tmp) ? "Empty" : tmp * volIncBeadsPlate
   }
   
	// if you get to here everything is ok!
	return true
}

function formSetAcN50 () {
	formInfo = ""

   if (doBeadsAcN && volBeads <=0) {
      formInfo = "No beads? No party! Disabling beads + AcN addition."
      doBeadsAcN = false
	   return false
   }
   
   if (!doReduction || !doAlkylation || !doBeadsAcN) {
	   formInfo = "Warning: addition of some key compounds is disabled"
   }

   var _volReduction = (doReduction) ? volReduction : 0
   var _volAlkylation = (doAlkylation) ? volAlkylation : 0
   var _volBeads = (doBeadsAcN) ? volBeads : 0
   
   var tmp = volStart + _volReduction + _volAlkylation + _volBeads

   if (2*tmp  > sampleMaxVol) {
      volBeadsAcN = 0
      formInfo = "Volume of AcN would exceed sample plate capacity!"
	   return false 
   }
   else {
      volBeadsAcN = tmp
	   return true 
   }
 }


print("formVolFuncs.js read")


tipsLoc3 = {
   statusCols: [],
   updateCols: function() {
      print("received global statusColsString = " + statusColsString)
	  // making sure that the resulting array is for 96 tip boxes
	  // using slice for keeping only the first 12 elements
      this.statusCols = statusColsString.split(",").slice(0,12)
      // need to call colsFormUpdate function 
      // which works in the global context
      colsFormUpdate() 
   },
   checkCols: function(availCols) {
      var cleanFound, emptyFound, tmpString, fullString, tmpIndex
      var cleanCount = 0
      fullString = this.statusCols.join("")

      // 1 - how many clean columns are available on the left and are they >= availCols? 
      tmpString = "C"
      while (!fullString.indexOf(tmpString)) {
         cleanCount++
         tmpString +="C"
      }
      cleanFound = (cleanCount >= availCols) ? true : false

      // 2 - are there any "availCols" empty cols anywhere?  
      tmpString = ""
      for (var i = 0; i < availCols; i++) tmpString += "E"  
      // lastIndexOf() starts for the end of fullString
      tmpIndex = fullString.lastIndexOf(tmpString)
      emptyFound = (tmpIndex >=0) ? true : false

      if (cleanFound && emptyFound) {
         return {
            tipsOK: true,
            tipsOff: tmpIndex+1,
            Mcols: cleanCount - availCols,
            Ncols: availCols
         }
      }
      else {
		  alert() // play a sound if tips status is not valid
         return {
            tipsOK: false
         }
      }   
   },
   shiftCols: function shiftCols (M,N) {
      print("Before shiftCols: " + this.statusCols.join(",")) 
      // shift M cols by N and set the remaining N to empty
      for (var i = 0; i < M+N; i++) {
         this.statusCols[i] = (i>M-1) ? "E" : this.statusCols[i+N]
      }
      print("After shiftCols: " + this.statusCols.join(",")) 
      //write the status to the interface
      statusColsString = this.statusCols.join(",")
      colsFormUpdate() 
   },
   tipsOnUpdate: function (N) {   
      print("Before tipsOnUpdate: " + this.statusCols.join(",")) 
      for (i=0; i < N; i++) {
         this.statusCols[i] = "E"
      }
      print("After tipsOnUpdate: " + this.statusCols.join(",")) 
      //write the status to the interface
      statusColsString = this.statusCols.join(",")
      colsFormUpdate() 
   },
   tipsOffUpdate: function (P,N) {
      print("Before tipsOffUpdate: " + this.statusCols.join(",")) 
      for (i = P-1; i < P-1+N; i++) {
         this.statusCols[i] = "U"
      }
      print("After tipsOffUpdate: " + this.statusCols.join(",")) 
      //write the status to the interface
      statusColsString = this.statusCols.join(",")
      colsFormUpdate() 
   },
   tipsOffCleanUpdate: function (P,N) {
      print("Before tipsOffCleanUpdate: " + this.statusCols.join(",")) 
      for (i = P-1; i < P-1+N; i++) {
         this.statusCols[i] = "C"
      }
      print("After tipsOffCleanUpdate: " + this.statusCols.join(",")) 
      //write the status to the interface
      statusColsString = this.statusCols.join(",")
      colsFormUpdate() 
   }      
}


// Reservoir constructor. Note: pass it a function that 
// takes a volume and calculates the DFWB according to a known geometry
var Reservoir = function (myDFWB,sName,sVol,sWS) {
	if (!myDFWB) {
		print("no function for DFWB passed to contructor!")
		task.pause()
		return
	}
	if (!sVol) {
		print("no or zero starting volume passed to contructor!")
		task.pause()
		return
	}
	if (!sWS) {
		print("no wellselection passed to contructor!")
		task.pause()
		return
	}
	if (!sName) {
		print("no column name passed to contructor!")
		task.pause()
		return
	}
	// closure
	var sName = sName
	var sVol = sVol
	var sWS = sWS
	var debug = true
	// remember: here "this" refers to global scope
	function setGlobalVar (_myVar,_myVol) { this[_myVar] = _myVol }
	this.solvAsp = function (v) {
		if (debug) print("Volume before aspirating " + sName +" = " + sVol)
		sVol -= v
		var dist = myDFWB(sVol)
		if (debug) print ("Aspirating " + v + " uL of " + sName + " at " + dist + " mm over flat bottom with wellsel = " + sWS)
		if (debug) print("Volume after aspirating " + sName + " = " + sVol)
		// automatically modify reservoir volume in the form
		setGlobalVar("reagVol"+ sName , sVol)
		return { dist: dist, wellsel: sWS, sVol: sVol }
	}
	this.solvRefill = function (v) {
		if (debug) print("Volume before refilling " + sName +" = " + sVol)
		sVol += v
		if (debug) print("Volume after refilling " + sName +" = " + sVol)
		// automatically modify reservoir volume in the form
		setGlobalVar("reagVol"+ sName , sVol)
		return { sVol: sVol, wellsel: sWS }
	}
	this.getData = function () {
		return {sName:sName,sVol:sVol,sWS:sWS}
	}
}
